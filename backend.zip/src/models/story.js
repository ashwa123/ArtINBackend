class Story {
    constructor(obj) {
        this.location = obj.location,
        this.scene = obj.scene,
        this.conversation = obj.conversation,
        this.sceneimage = obj.sceneimage
    }
}

module.exports = Story;