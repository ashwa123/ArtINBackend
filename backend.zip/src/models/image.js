class Image {
    constructor(obj) {
        this.title = obj.title
        this.profileimage = obj.profileimage,
        this.avatar = obj.avatar
    }
}

module.exports = Image;
