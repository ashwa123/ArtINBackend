class Title {
    constructor(obj) {
        this.title = obj.title
    }
}

module.exports = Title;