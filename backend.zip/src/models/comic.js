class Comics {
    constructor(obj) {
        this.title = obj.title,
        this.genre = obj.genre,
        this.about = obj.about
    }
}

module.exports = Comics;