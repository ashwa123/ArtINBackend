class Chapter {
    constructor(obj) {
        this.chaptername = obj.chaptername
    }
}

module.exports = Chapter;